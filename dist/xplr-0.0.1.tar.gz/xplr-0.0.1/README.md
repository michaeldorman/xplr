# `xplr`

[![badge](https://img.shields.io/pypi/v/xplr)](https://pypi.org/project/xplr/)

## Overview

The `xplr` package

## Import on startup

Create a startup script, such as `~/.python_startup.py`:

```python
from xplr import plot
from xplr import view
```

For the script to be automatically executed on `python` startup, add this in your `.bashrc`:

```python
export PYTHONSTARTUP=~/.python_startup.py
```

In addition, for the script to be automatically executed on `ipython` startup, create ipython profiles (if you don't already have them):

```python
ipython profile create
```

Then, uncomment the following expression in `~/.ipython/profile_default/ipython_config.py`:

```python
c.InteractiveShellApp.exec_PYTHONSTARTUP = True
```


